CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Project Files
 * How to Run
 * Creator

INTRODUCTION
------------

Project 1's goal was to create utilize the fresh_tomatoes.py method in order to
create a webpage that contained movies with the following information:
    * Movie Title
    * Youtube Trailer URL
    * Movie Poster URL

PROJECT FILES
-------------

* entertainment_center.py
* fresh_tomatoes.py
* media.py

HOW TO RUN
----------

In order to run and test Project 1 from the command line enter the directory
containing the project files and enter "python entertainment_center.py" into
the command line.  Following the execution of this command your default browser
should open containing the fresh tomatoes web page with three movies.

AUTHOR
------

* Josh Panka